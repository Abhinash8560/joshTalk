

export const QUIZ_REQUEST = "QUIZ_REQUEST"
export const QUIZ_SUCCESS = "QUIZ_SUCCESS"
export const QUIZ_FAIL = "QUIZ_FAIL"

