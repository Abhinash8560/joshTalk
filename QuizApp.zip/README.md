# React + Vite

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh


                       /* project description */

 I have made the application QuizApp using reactjs and redux.I have made this application responsive for all screen-sizes and it is adaptable for all different device sizes and it is compatible with the latest versions of major browsers such as Chrome, Firefox, Safari, and Edge.So,I have made condition based on user enter their correct email address then only it will show quiz application page.In the quiz application,i have implemented timer,quiz section and overviewPanel.I have implement gsap library for showing animation when user switch between the question.And  if visited any question then it will show that section in yellow color and i also made the condition like initially it will show ✘ this symbol for question,but if the question gets attempted then it change to ✔.After 30 min the timer gets stops and it will show score in message and it gets route to report page.